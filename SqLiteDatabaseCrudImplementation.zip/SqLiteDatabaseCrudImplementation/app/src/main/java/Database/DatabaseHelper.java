package Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.orhanobut.logger.AndroidLogAdapter;

import java.util.logging.Logger;

import Util.Config;

import static Util.Config.TABLE_NAME;

public class DatabaseHelper extends SQLiteOpenHelper {


    private static DatabaseHelper databaseHelper;

    //All static variable
    private static final int DATABASE_VERSION=5;


    //Database Name
    private static final String DATABASE_NAME= Config.DATABASE_NAME;

    //Constructor

    private DatabaseHelper(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
      //  Logger.addLogAdapter(new AndroidLogAdapter());
    }


    public static synchronized DatabaseHelper getInstance(Context context){
        if(databaseHelper==null){
            databaseHelper=new DatabaseHelper(context);
        }
        return databaseHelper;
    }



    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create tables SQL execution
        String CREATE_STUDENT_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + Config.COLUMN_STUDENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Config.COLUMN_STUDENT_NAME + " TEXT NOT NULL, "
                + Config.COLUMN_STUDENT_REGISTRATION + " INTEGER NOT NULL UNIQUE, "
                + Config.COLUMN_STUDENT_PHONE + " TEXT, " //nullable
                + Config.COLUMN_STUDENT_EMAIL + " TEXT " //nullable
                + ")";

        // should student Id  be Auto Increment???

       // Logger.d("Table Create SQL: "+CREATE_STUDENT_TABLE);
        db.execSQL(CREATE_STUDENT_TABLE);

    //    Logger.d("DB Created");



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //drop older table if existed

        db.execSQL("DROP TABLE IF EXISTS "+Config.TABLE_NAME);


        //create table again
        onCreate(db);



    }
}
