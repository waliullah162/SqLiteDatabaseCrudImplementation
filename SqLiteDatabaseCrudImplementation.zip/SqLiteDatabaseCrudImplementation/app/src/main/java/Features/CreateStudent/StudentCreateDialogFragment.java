package Features.CreateStudent;

import android.app.Dialog;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.sqlitedatabasecrudimplementation.R;

import Database.DatabaseQueryClass;
import Util.Config;


//create student dialog fragment

public class StudentCreateDialogFragment extends DialogFragment implements View.OnClickListener {


    //create instance of all the widgets inside this fragment

    private EditText nameEditText;
    private EditText registratonEditText;
    private EditText phoneEditText;
    private EditText emailEditText;

    private Button createButton;
    private Button cancelButton;


    private String nameString="";
    private long registrationNumber=-1;
    private String phoneString="";
    private String emailString="";



    public static StudentCreateListener studentCreateListener;

    //default constructor

    public StudentCreateDialogFragment(){

    }


    public static StudentCreateDialogFragment newInstance(String title, StudentCreateListener listener){

        studentCreateListener=listener;
        StudentCreateDialogFragment studentCreateDialogFragment=new StudentCreateDialogFragment();
        Bundle args=new Bundle();
        args.putString("title",title);
        studentCreateDialogFragment.setArguments(args);

        studentCreateDialogFragment.setStyle(DialogFragment.STYLE_NORMAL,R.style.CustomDialog);

        return studentCreateDialogFragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_student_create_dialog, container, false);

        nameEditText=view.findViewById(R.id.studentNameEditText);
        registratonEditText=view.findViewById(R.id.registrationEditText);
        phoneEditText=view.findViewById(R.id.phoneEditText);
        emailEditText=view.findViewById(R.id.emailEditText);

        createButton=view.findViewById(R.id.createButton);
        cancelButton=view.findViewById(R.id.cancelButton);


        String title=getArguments().getString(Config.TITLE);
        getDialog().setTitle(title);


        //add button onClick listener with createButton

        createButton.setOnClickListener(this);
        cancelButton.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {


        switch(view.getId()){
            case R.id.createButton:

                createButtonMethod();
                break;


            case R.id.cancelButton:
                cancelButtonMethod();
                break;

                //default case, is it necessary to handle


        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog=getDialog();
        if(dialog!=null){
            int width=ViewGroup.LayoutParams.MATCH_PARENT;
            int height=ViewGroup.LayoutParams.WRAP_CONTENT;

            //noinspection ConstantCondition

            dialog.getWindow().setLayout(width,height);


        }
    }

    //create Button Method

    private void createButtonMethod() {

        //Get the student information from create form

        nameString=nameEditText.getText().toString();
        registrationNumber=Integer.parseInt(registratonEditText.getText().toString());
        phoneString=phoneEditText.getText().toString();
        emailString=emailEditText.getText().toString();


        //pass the student information to Student model class

        Student student= new Student(-1,nameString,registrationNumber,phoneString,emailString);


        //Create an instance for the DatabaseQueryClass and pass the context by getting it by getContext() method

        DatabaseQueryClass databaseQueryClass=new DatabaseQueryClass(getContext());

        //After successfully created the student table by the CreateStudent() method will return the long type  id
        //we will take it

        long id=databaseQueryClass.insertStudent(student);

        if(id>0){
            student.setId(id);
            //why do we call here this click listener
            studentCreateListener.onStudentCreated(student);

            //what is the task of dismiss
            getDialog().dismiss();
        }

    }


    //Cancel Button method and its activities

    private void cancelButtonMethod() {

        getDialog().dismiss();

    }
}