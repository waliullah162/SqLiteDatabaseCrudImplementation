package Features.CreateStudent;

public interface StudentCreateListener {

   void onStudentCreated(Student student);
}
