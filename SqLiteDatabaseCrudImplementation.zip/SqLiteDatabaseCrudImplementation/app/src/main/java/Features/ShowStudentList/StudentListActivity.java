package Features.ShowStudentList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;


import Database.DatabaseHelper;
import Database.DatabaseQueryClass;
import Features.CreateStudent.Student;
import Features.CreateStudent.StudentCreateDialogFragment;
import Features.CreateStudent.StudentCreateListener;
import Util.Config;

import com.example.sqlitedatabasecrudimplementation.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.orhanobut.logger.AndroidLogAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

//MainActivity
public class StudentListActivity extends AppCompatActivity implements StudentCreateListener {

   private DatabaseQueryClass databaseQueryClass;

   private List<Student>studentList=new ArrayList<>();

   private TextView studentListEmptyTextView;
   private RecyclerView recyclerView;
   private StudentListRecyclerViewAdapter studentListRecyclerViewAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       // Logger.addLogAdapter(new AndroidLogAdapter());


        databaseQueryClass =new DatabaseQueryClass(this);

        recyclerView=findViewById(R.id.studentRecyclerView);
        studentListEmptyTextView=findViewById(R.id.emptyStudentListTextView);



        studentList.addAll(databaseQueryClass.getAllStudent());




        studentListRecyclerViewAdapter=new StudentListRecyclerViewAdapter(this, studentList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));


        viewVisibility();


        FloatingActionButton fab=findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStudentCreateDialog();
            }
        });



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       if(item.getItemId()==R.id.action_delete){
           final AlertDialog.Builder alertDialogBuilder=new AlertDialog.Builder(this);
           alertDialogBuilder.setMessage("Are u sure, you want to delete All Students?");
           alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
               @Override
               public void onClick(DialogInterface dialog, int which) {

                   boolean isAllDeleted = databaseQueryClass.deleteAllStudents();
                   if(isAllDeleted){
                       studentList.clear();
                       studentListRecyclerViewAdapter.notifyDataSetChanged();
                       viewVisibility();
                   }
               }
           });

           alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
               @Override
               public void onClick(DialogInterface dialog, int which) {
                   dialog.dismiss();
               }
           });


           AlertDialog alertDialog=alertDialogBuilder.create();
           alertDialog.show();
       }

        return super.onOptionsItemSelected(item);

    }

    public void viewVisibility(){
        if(studentList.isEmpty())
            studentListEmptyTextView.setVisibility(View.VISIBLE);
        else
            studentListEmptyTextView.setVisibility(View.GONE);
    }


    private void openStudentCreateDialog(){
        StudentCreateDialogFragment studentCreateDialogFragment=StudentCreateDialogFragment.newInstance("Create Student",this);
        studentCreateDialogFragment.show(getSupportFragmentManager(), Config.CREATE_STUDENT);
    }

    @Override
    public void onStudentCreated(Student student) {

        studentList.add(student);
        studentListRecyclerViewAdapter.notifyDataSetChanged();
        viewVisibility();
       // Logger.d(student.getName());

    }
}