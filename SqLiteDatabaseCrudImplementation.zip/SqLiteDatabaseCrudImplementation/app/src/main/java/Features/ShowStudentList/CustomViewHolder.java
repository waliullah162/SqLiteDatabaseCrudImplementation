package Features.ShowStudentList;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sqlitedatabasecrudimplementation.R;

public class CustomViewHolder extends RecyclerView.ViewHolder {

    //As we will use these variables outside of the class, we won't declare its private
     TextView nameTextView;
     TextView registrationNumTextView;
     TextView emailTextView;
     TextView phoneTextView;
     ImageView crossButtonImageView;
     ImageView editButtonImageView;



    public CustomViewHolder(@NonNull View itemView) {
        super(itemView);

        nameTextView=itemView.findViewById(R.id.nameTextView);
        registrationNumTextView=itemView.findViewById(R.id.registrationNumTextView);
        emailTextView=itemView.findViewById(R.id.emailTextView);
        phoneTextView=itemView.findViewById(R.id.phoneTextView);
        crossButtonImageView=itemView.findViewById(R.id.crossImageView);
        editButtonImageView=itemView.findViewById(R.id.editImageView);

    }
}
