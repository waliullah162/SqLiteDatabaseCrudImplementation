package Features.UpdateStudentInfo;

import Features.CreateStudent.Student;

public interface StudentUpdateListener {

   void onStudentInfoUpdated(Student student, int position);
}
